#!/usr/bin/env sh
mysqld_safe