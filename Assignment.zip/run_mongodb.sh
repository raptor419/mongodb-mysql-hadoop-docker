#!/bin/sh
exec /sbin/setuser mongodb /usr/bin/mongod